﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt_bank_swiatek
{
    public class BUSINESS_ACCOUNT : ACCOUNT
    {
        public BUSINESS_ACCOUNT(int account_id, string user_name, string password, int cash_ammount) : base (account_id, user_name, password, cash_ammount)
        {
            this.type = "biznesowe";
        }
    }
}
