﻿namespace projekt_bank_swiatek
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<ACCOUNT> accounts = new List<ACCOUNT>
            {
                new ACCOUNT(1, "aNowak", "haslo123", 4000),
                new ACCOUNT(2, "pKoziol", "haslo123", 2000),
                new ACCOUNT(3, "cTybura", "haslo123", 6000),
                new BUSINESS_ACCOUNT(4, "aJolisz", "haslo123", 7000)
            };
            ACCOUNT logged_in_acc = null;
            string user_name, password;
            do
            {
                Console.WriteLine("Podaj nazwe uzytkownika: ");
                user_name = Console.ReadLine();
                Console.WriteLine("Podaj hasło: ");
                password = Console.ReadLine();

                logged_in_acc = accounts.FirstOrDefault(acc => acc.user_name == user_name && acc.password == password);
                if(logged_in_acc != null)
                {
                    logged_in_acc.login(user_name, password);
                }
                else
                {
                    Console.WriteLine("Takie konto nie istnieje.");
                }
            } while (logged_in_acc == null);

            while (true)
            {
                if (logged_in_acc.is_logged)
                {
                    Console.WriteLine("Co chciałbyś zrobić: ");
                    Console.WriteLine("1. Wykonać przelew");
                    Console.WriteLine("2. Wpłacić pieniądze");
                    Console.WriteLine("3. Wyświetlić informacje o koncie");
                    Console.WriteLine("4. Wyświetlić historię");
                    Console.WriteLine("5. Zapisać wyciąg do pliku");
                    Console.WriteLine("6. Wyjście");

                    string choice = Console.ReadLine();

                    switch (choice)
                    {
                        case "1":
                            Console.WriteLine("Na jak duża kwotę chcesz wykonać przelew?");
                            int ammount = Convert.ToInt32(Console.ReadLine());
                            logged_in_acc.make_payment(logged_in_acc, ammount);
                            break;
                        case "2":
                            Console.WriteLine("Ile gotówki chcesz wpłacić?");
                            int ammount_ = Convert.ToInt32(Console.ReadLine());
                            logged_in_acc.deposit_money(logged_in_acc, ammount_);
                            break;
                        case "3":
                            Console.WriteLine("Oto dane twojego konta: \n");
                            logged_in_acc.show_user_info();
                            logged_in_acc.show_account_info();
                            break;
                        case "4":
                            Console.WriteLine("Oto historii operacji na twoim koncie:\n");
                            logged_in_acc.show_history();
                            break;
                        case "5":
                            Console.WriteLine("Podaj nazwe pliku, do którego chcesz zapisać swoją historię: ");
                            string file_name = Console.ReadLine();
                            logged_in_acc.save_to_file(file_name);
                            Console.WriteLine($"Historia została zapisana do pliku: {file_name}");
                            break;
                        case "6":
                            return;
                        default:
                            Console.WriteLine("Wybrano niepoprawną opcje.");
                            break;
                    }
                   
                }
            }
            
        }
    }
}
