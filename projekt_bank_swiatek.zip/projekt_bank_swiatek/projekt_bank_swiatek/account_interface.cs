﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt_bank_swiatek
{
    internal interface ACCOUNT_INTERFACE
    {
        void login(string username, string password);
        void show_user_info();
        void show_account_info();
        void show_history();
        ACCOUNT make_payment(ACCOUNT account, int amount);
        ACCOUNT deposit_money(ACCOUNT account, int amount);
        string serialize_history();
        void deserialize_history(string json);
        void save_to_file(string file_path);
        void load_from_file(string file_path);
    }
}
