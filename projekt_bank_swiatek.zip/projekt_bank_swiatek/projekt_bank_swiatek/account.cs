﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;

namespace projekt_bank_swiatek
{
    public class ACCOUNT : ACCOUNT_INTERFACE
    {
        public int account_id;
        public string user_name;
        public string password;
        public string type;
        public int cash_ammount;
        public List<string> history;
        public bool is_logged;

        public ACCOUNT(int account_id, string user_name, string password, int cash_ammount)
        {
            this.account_id = account_id;
            this.user_name = user_name;
            this.password = password;
            this.type = "standard";
            this.cash_ammount = cash_ammount;
            this.history = new List<string>();
            this.is_logged = false;
        }
        public void login(string username, string password) 
        {
            if(username == this.user_name && password == this.password)
            {
                this.is_logged = true;
                Console.WriteLine("Zalogowano poprawnie.");
            }
            else
            {
                Console.WriteLine("Niesety podałeś niepoprawne dane.");
            }
        }
        public virtual void show_user_info()
        {
            Console.WriteLine($"Twój numer konta to: {account_id}, typ twojego konta to: {type}.");
        }

        public void show_account_info()
        {
            Console.WriteLine($"Na twoim koncie znajduję się aktualnie : {cash_ammount} PLN.");
        }
        public void show_history()
        {
            if(history != null && history.Count > 0 ) 
            {
                foreach(var entry in history)
                {
                    Console.WriteLine(entry);
                }
            }
            else
            {
                Console.WriteLine("Brak historii do wyświetlenia.");
            }
        }
        public ACCOUNT make_payment(ACCOUNT account, int ammount)
        {
            Console.WriteLine($"Zaraz dokonasz płatności na kwotę {ammount}, dziękujemy za skorzystanie z naszych usług.");
            account.cash_ammount -= ammount;
            account.history.Add(DateTime.Now.ToString("dddd, dd MMMM yyyy HH:mm:ss") + $": Dokonano płatności na {ammount} PLN"); return account;
        }

        public ACCOUNT deposit_money(ACCOUNT account, int ammount) 
        {
            Console.WriteLine($"Właśnie wpłacamy na twoje konto {ammount} PLN, dziękujemy za skorzystanie z naszych usług.");
            account.cash_ammount += ammount;
            account.history.Add(DateTime.Now.ToString("dddd, dd MMMM yyyy HH:mm:ss") + $": Dokonano płatności na {ammount} PLN"); return account;
        }

        public string serialize_history()
        {
            return JsonSerializer.Serialize(this.history);
        }
        public void deserialize_history(string json)
        {
            this.history = JsonSerializer.Deserialize<List<string>>(json);
        }
        public void save_to_file(string file_path)
        {
            string json = serialize_history();
            File.WriteAllText(file_path, json);
        }
        public void load_from_file(string file_path)
        {
            if(File.Exists(file_path))
            {
                string json = File.ReadAllText(file_path);
                deserialize_history(json);
            }
            else
            {
                Console.WriteLine($"Plik {file_path} nie istnieje.");
            }
            
        }
    }
}
